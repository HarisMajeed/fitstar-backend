const bcrypt = require("bcrypt");
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const sponsorSchema = new Schema(
  {
    image: { type: String, default: "" }
  },
  { timestamps: true, versionKey: false }
);

const Sponsor = mongoose.model("Sponsors", sponsorSchema);

module.exports = Blog;
