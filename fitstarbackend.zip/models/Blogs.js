const bcrypt = require("bcrypt");
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const blogSchema = new Schema(
  {
    title: { type: String, default: "" },
    descrption: { type: String, default: "" },
    authorName: { type: String },
    category: { type: String, default: "" },
    featuredImages: [],
    authorImage: { type: String, default: "" },
    videoLink: { type: String, default: "" },
    details: { type: String, default: "" },
  },
  { timestamps: true, versionKey: false }
);

const Blog = mongoose.model("Blogs", blogSchema);

module.exports = Blog;
